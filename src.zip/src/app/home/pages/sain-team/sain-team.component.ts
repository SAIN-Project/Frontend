import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-sain-team",
    templateUrl: "./sain-team.component.html",
    styleUrls: ["./sain-team.component.css"],
})
export class SainTeamComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}

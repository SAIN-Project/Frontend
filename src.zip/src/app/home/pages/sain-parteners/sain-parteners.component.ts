import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sain-parteners',
  templateUrl: './sain-parteners.component.html',
  styleUrls: ['./sain-parteners.component.css']
})
export class SainPartenersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

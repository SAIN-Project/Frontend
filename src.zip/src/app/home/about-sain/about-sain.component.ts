import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-about-sain",
    templateUrl: "./about-sain.component.html",
    styleUrls: ["./about-sain.component.css"],
})
export class AboutSainComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}

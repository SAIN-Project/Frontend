
import {Control}   from 'rete'
export interface Controls extends Control  {
    validate():any
}
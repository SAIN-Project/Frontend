import { 
    Component,OnInit, AfterViewInit, ViewChild, ElementRef ,Renderer2,Input,Output
} from '@angular/core';
import { NodeEditor, Engine } from 'rete';
import {ReteHttpService} from '../../services/rete-http.service'
import {ReteService} from '../../services/rete.service'
import {ToolService} from'../../services/tool.service'
import * as Components  from '../Classes/components'
import {ModalService} from '../../services/modal.service'
import {Editor} from '../Classes/Editor'
import{saveAs} from'file-saver'
import {RoutingService} from '../../services/routing.service'
import { AdminService } from '../../services/admin.service';
declare var $:any

@Component({
    selector: 'app-editor',
    templateUrl: './templates/editor.component.html',
    styleUrls: ['./node-editor.scss','../node.scss']
})
export class EditorComponent implements AfterViewInit ,OnInit {

    components:any[] = [
        new Components.FileUploader(this.http),
        new Components.ProjectFilePath(this.http),
    
    ];
    EditorFactory:Editor
    DatabaseReteComponents:any[]=[];
    @ViewChild('nodeEditor', { static: true }) el: ElementRef;
    constructor(
        public toolservice:ToolService,
        public http:ReteHttpService,
        public renderer: Renderer2,
        public modal :ModalService,
        public rete:ReteService
    ){}

    ngOnInit(){
        $(document).ready(function () {
      
            $('#terminal').toggleClass('active').removeClass('d-none');
            $('#vars').toggleClass('active').removeClass('d-none');
            $('#sidebarCollapse i,#dismiss').on('click', function () {
                $('.left-sidebar').toggleClass('active');
                $('#sidebarCollapse i').toggleClass('hidden')
            });
            $('#vars-collapse,#vars-dismiss').on('click', function () {
              $('#vars').toggleClass('active');
            });
            $('#terminal-collapse,#terminal-dismiss').on('click', function () {
              $('#terminal').toggleClass('active');
            });
      
            $('nav ul li').click(function(){
              $(this).addClass("active").siblings().removeClass("active");
            });   
        });
        this.EditorFactory=new Editor(this.http)

    }
    async ngAfterViewInit(){
        const container = this.el.nativeElement;
        var sockets:any[]=await this.rete.getSocketsNames();
        sockets.forEach(socket=>{
            Components.SocketManagment.createSocket(socket)
        })
        this.DatabaseReteComponents=await this.rete.getRetes();
        this.DatabaseReteComponents.forEach(item=>{
            var component=new  Components.GeneratedComponent(item.name,JSON.parse(item.contents),this.http)
            this.components.push(component);
        })
        this.EditorFactory.components=this.components;
        this.EditorFactory.createEditor(container)

    }
    
}

@Component({
    selector: 'app-editor-list',
    templateUrl: './templates/componentlist.component.html',
    styleUrls: ['../node.scss']
})
export class ListComponent implements AfterViewInit ,OnInit {
    @Input() components:any[]
    Categories:any[]
    searchComponents=[];
    SearchTerm=''  
    constructor(
        public toolservice:ToolService,
        public http:ReteHttpService,
    ){}
    
    async ngOnInit(){
        this.Categories=await this.toolservice.getCategoryList()
        this.Categories=this.Categories.filter(item=>item.key=='Category')[0].values;
        this.filterComponents();
    }
    async ngAfterViewInit(){

    }
    addComponent(event,name){
        event.dataTransfer.setData('componentName', name);
    }
    findComponents(path:string){
        if(this.SearchTerm=='')
            return this.components.filter(c=>c.path.includes(path));
        else
            return this.searchComponents.filter(c=>c.path.includes(path));
    }
    filterComponents(){
        this.searchComponents=this.components.filter(c=>c.name.toLowerCase().includes(this.SearchTerm.toLowerCase()))
    }
    
}

@Component({
    selector: 'app-editor-terminal',
    templateUrl: './templates/terminal.component.html',
    styleUrls: ['../node.scss']
})
export class TerminalComponent implements AfterViewInit ,OnInit {
    mode:boolean=true;
    counter=0;
    constructor(
        public toolservice:ToolService,
        public http:ReteHttpService,
        public renderer: Renderer2,
        public modal :ModalService,
    ){}
    @ViewChild('term', { static: true }) terminal: ElementRef;
    ngOnInit(){

    }
    async ngAfterViewInit(){
              
    }   
    clear(){
        this.http.socketoutput=[];
    } 
}

@Component({
    selector: 'app-editor-outputblackboard',
    templateUrl: './templates/outputblackboard.component.html',
    styleUrls: ['../node.scss']
})
export class OutputBlackboardComponent implements AfterViewInit ,OnInit {
    constructor(
        public toolservice:ToolService,
        public http:ReteHttpService,
        public modal :ModalService,
    ){}
    
    ngOnInit(){

    }
    async ngAfterViewInit(){

    }
    getFileName(filepath:string){
        if(!filepath) return ''
        var index=filepath.lastIndexOf('/')
        var filename=filepath.substring(index+1)
        if(filename.indexOf('.')==-1) filename=filename+'.zip'
        return filename;
    }
    getData(data:any){
        if(data instanceof Object){
            if(data['filepath']){
                var filepath=data['filepath']
                var index=filepath.lastIndexOf('\\')
                var filename=filepath.substring(index+1)
                return filename;
            }
        }
        return data;
    }
    copyFilePath(filepath:string){
        navigator.clipboard.writeText(filepath).then().catch(e => console.error(e));
    }
    
}
@Component({
    selector: 'app-editor-navbar',
    templateUrl: './templates/navbar.component.html',
    styleUrls: ['../node.scss']
})
export class NavbarComponent implements AfterViewInit ,OnInit {
    @Input() Editor:Editor

    sample = {
        name: "",
        file: new File([""], "", { type: "" }),
        contents: "",        
    };
    
    public Samples:any=[]
    public ready2runSamples:any=[];
    CurrentZoomIntensity=8;

    constructor(
        public toolservice:ToolService,
        public http:ReteHttpService,
        public modal :ModalService,
        public router:RoutingService,
        public admin: AdminService
    ){}
    
    ngOnInit(){
        this.toolservice.getSamples().subscribe(response=>{
            this.Samples=response; 
        },error=>{
            console.log('error')
        })

        this.toolservice.getready2runSamples().subscribe(response=>{
            this.ready2runSamples=response; 
        },error=>{
            console.log('error')
        })
    }
    async ngAfterViewInit(){

    }
    async start(template){
        await this.http.setupSocketConnection()
        this.http.CompletedProcess=[];
        this.http.socketoutput=[];
        if(this.Editor.Editor.nodes.length>0){
            this.http.ValidatorErrors=[]
            var validator=new Components.Validator(this.http)
            for(var node of this.Editor.Editor.nodes){
                validator.validate(node)
            }
            if(this.http.ValidatorErrors.length) {
                console.log(this.http.ValidatorErrors)
                this.modal.open(template)
            }
            else{
                this.http.socket.on('data', (data: string) => {
                    if(data.length>1000) 
                        data=data.substring(0,1000)+' ...  '
                    if((data!='') && this.http.TerminalStreamingMode==true)
                        this.http.socketoutput.push({type:'data',data});
                    var element = document.getElementById("terminal");
                    element.scrollTop = element.scrollHeight;
                });
                this.http.socket.on('error', (data: string) => {
                    if(data!='') 
                        this.http.socketoutput.push({type:'error',data})
                    var element = document.getElementById("terminal");
                    element.scrollTop = element.scrollHeight;
                });
                this.Editor.isProcessing=true;
                await this.Editor.Editor.trigger('process')
            }
        }  
    }
    stop(){
        
        this.Editor.Engine.abort().then(()=>{
            this.Editor.isProcessing=false;
            this.http.CurrentRuningProcess=[];
        })

    }
    hasNodes(){
        if(this.Editor.Editor==null) return false;
        if(this.Editor.Editor.nodes.length==0) return false;
        return true;
    }

    onZoomChange(value){
   
        if(!this.hasNodes()) return;
        if((this.CurrentZoomIntensity==1 && value==-1)||(this.CurrentZoomIntensity==16 && value==1)) return;
        this.CurrentZoomIntensity+=value;
        this.Editor.onRangeChange(this.CurrentZoomIntensity)
    }
    importFromJson(event){
        this.http.CompletedProcess=[];
        if (event.target.files.length > 0) {
            var file = <File>event.target.files[0];
            const fileReader = new FileReader();
            fileReader.readAsText(file, "UTF-8");
            fileReader.onloadend = () => {
                const json=JSON.parse(<string>fileReader.result)
                this.Editor.Editor.fromJSON(json)
            }
            fileReader.onerror = (error) => {
                console.log(error);
            }
        }
        
    }
    exportToJson(){
        var data=this.Editor.Editor.toJSON()
        const blob = new Blob([JSON.stringify(data)], {type : 'application/json'});
        saveAs(blob, 'editor.json');
    }
    clear(){
        this.Editor.Editor.clear();
    }
    
    loadSample(item){
        this.modal.hide()
        const json=JSON.parse(<string>item.contents)        
        this.Editor.Editor.fromJSON(json)        
    }

    loadReady2runSample(item){
        this.modal.hide()
        const json=JSON.parse(<string>item.contents)          
        this.Editor.Editor.fromJSON(json)
    }

    uploadReady2runSubmit() {
        var data = new FormData();
        data.append("name", this.sample.name); 

        var jsonExport=this.Editor.Editor.toJSON()
        var stringjsonExport = JSON.stringify(jsonExport)        
        data.append("contents", stringjsonExport);

        this.admin.addReady2runSample(data).subscribe(
            (res) => {
                this.ready2runSamples = res;
                this.sample.name = "";
                this.sample.file = new File([""], "", { type: "" });
                this.modal.hide();  
            },
            (err) => {
                console.log(err);
                alert(err.error.message);                
            }
        );
    }

    onFileSelected(event) {
        if (event.target.files.length > 0) {
            this.sample.file = <File>event.target.files[0];
            const fileReader = new FileReader();
            fileReader.readAsText(this.sample.file, "UTF-8");
            fileReader.onloadend = () => {
                this.sample.contents = <string>fileReader.result;
            };
            fileReader.onerror = (error) => {
                console.log(error);
            };
        }
    }

    // loadReady2runSample(item){    
    //     this.modal.hide()
    //     const json=JSON.parse(<string>item.contents)
    //     // Get filename and class path from backend
    //     const filename = item.filename        
    //     // Load the editor
    //     this.Editor.Editor.fromJSON(json)
    //     // Get all loaded nodes
    //     let nodes = this.Editor.Editor.nodes
    //     // Get all inputs
    //     let inputs = item.inputs
    //     // Load files into the node       
    //     function loadNode(node, inputlist) { 
    //         var inputname:any;
    //         var filename:any;
    //         var filenameBlob:any;
    //         var file:any;

    //         for (let i = 0; i < inputlist.length; i++) {
    //             inputname = inputlist[i].inputname;
    //             filename = inputlist[i].filename;
    //             // Create file
    //             filenameBlob = new Blob([filename], {
    //                 type: "plain/text"
    //             })
    //             file = new File([filenameBlob], "sample_"+ filename);                
    //             node.inputs.get(inputname).control["props"].Filename = filename
    //             node.inputs.get(inputname).control["props"].value = file
    //             node.data[inputname] = file 
    //         }     
    //     }
    //     // Wait until array populated
    //     var timeout = setInterval(function() {
    //         if(nodes.length > 0) {
    //             clearInterval(timeout); 
    //             for (let i = 0; i < inputs.length; i++) {                    
    //                 let nodename = inputs[i].nodename  
    //                 let inputlist = inputs[i].inputlist                   
    //                 // Find the node that needs to be modified
    //                 for (let j = 0; j < nodes.length; j++) {                        
    //                     if (nodes[j].name === nodename) {
    //                         // Put placeholder file into the input (different for different nodes)    
    //                         console.log(nodes[j].inputs);
    //                         loadNode(nodes[j], inputlist);                            
    //                     }
    //                 }
    //             }            
    //         }
    //     }, 100);
    // }

    setLocalServerConnection(template:any){
        if(this.http.ToolEnginesServer!='Local')
            this.modal.open(template)

    }
    ExitEditor(exit){
        if(this.Editor.Editor.nodes.length>0){
            this.modal.open(exit,'modal-md')
        }
        else{
            this.router.navigateTo('/tool/tools')
        }
    }
    confirmExit(){
        this.router.navigateTo('/tool/tools')
        this.modal.hide();
    }
}

@Component({
    selector: 'app-docker-connector',
    templateUrl: './templates/dockerconnector.component.html',
    styleUrls: ['../node.scss']
})
export class DockerConnecter implements OnInit {
    isLoading=false;
    error=null;

    constructor(
        public http:ReteHttpService,
        public modal:ModalService,
        public router:RoutingService
    ){

    }
    ngOnInit(){

    }
    setLocalServer(){
        this.isLoading=true;
        this.error=null;
        this.http.isLocalServerAlive().subscribe((response)=>{
            this.http.ToolEnginesServer="Local";
            this.http.url=this.http.getLocalUrl();
            this.http.setupSocketConnection();
            this.isLoading=false;
            this.modal.hide();
        },(error)=>{
            this.isLoading=false;
            this.error=error;

        })
    }
}
